﻿namespace UiPath.Shared.Localization
{
    class SharedResources : SolFinder.JsonFormatConverter.Activities.Properties.Resources
    {
    }
}