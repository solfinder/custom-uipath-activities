namespace SolFinder.JsonFormatConverter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Json2xmlDesigner.xaml
    /// </summary>
    public partial class Json2xmlDesigner
    {
        public Json2xmlDesigner()
        {
            InitializeComponent();
        }
    }
}
