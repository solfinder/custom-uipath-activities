﻿namespace UiPath.Shared.Localization
{
    class SharedResources : SolFinder.JsonFormatConverter.Activities.Design.Properties.Resources
    {
    }
}