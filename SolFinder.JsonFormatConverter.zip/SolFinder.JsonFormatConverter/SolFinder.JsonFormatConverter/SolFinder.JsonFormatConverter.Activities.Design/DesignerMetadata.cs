using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using SolFinder.JsonFormatConverter.Activities.Design.Designers;
using SolFinder.JsonFormatConverter.Activities.Design.Properties;

namespace SolFinder.JsonFormatConverter.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(Json2xml), categoryAttribute);
            builder.AddCustomAttributes(typeof(Json2xml), new DesignerAttribute(typeof(Json2xmlDesigner)));
            builder.AddCustomAttributes(typeof(Json2xml), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
