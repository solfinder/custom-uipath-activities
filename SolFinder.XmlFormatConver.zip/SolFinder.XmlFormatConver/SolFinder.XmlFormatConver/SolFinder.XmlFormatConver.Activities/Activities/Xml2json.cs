using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using SolFinder.XmlFormatConver.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using Newtonsoft.Json;

namespace SolFinder.XmlFormatConver.Activities
{
    [LocalizedDisplayName(nameof(Resources.Xml2json_DisplayName))]
    [LocalizedDescription(nameof(Resources.Xml2json_Description))]
    public class Xml2json : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.Xml2json_XmlInput_DisplayName))]
        [LocalizedDescription(nameof(Resources.Xml2json_XmlInput_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> XmlInput { get; set; }

        [LocalizedDisplayName(nameof(Resources.Xml2json_JsonOutput_DisplayName))]
        [LocalizedDescription(nameof(Resources.Xml2json_JsonOutput_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> JsonOutput { get; set; }

        #endregion


        #region Constructors

        public Xml2json()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (XmlInput == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(XmlInput)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var xmlinput = XmlInput.Get(context);

            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlinput);
            string jsonText = JsonConvert.SerializeXmlNode(doc);
            // Outputs
            return (ctx) => {
                JsonOutput.Set(ctx, jsonText);
            };
        }

        #endregion
    }
}

