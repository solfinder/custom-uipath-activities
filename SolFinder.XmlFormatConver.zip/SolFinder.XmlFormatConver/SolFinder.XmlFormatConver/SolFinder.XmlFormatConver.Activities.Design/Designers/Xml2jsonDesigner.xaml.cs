namespace SolFinder.XmlFormatConver.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Xml2jsonDesigner.xaml
    /// </summary>
    public partial class Xml2jsonDesigner
    {
        public Xml2jsonDesigner()
        {
            InitializeComponent();
        }
    }
}
