using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using SolFinder.XmlFormatConver.Activities.Design.Designers;
using SolFinder.XmlFormatConver.Activities.Design.Properties;

namespace SolFinder.XmlFormatConver.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(Xml2json), categoryAttribute);
            builder.AddCustomAttributes(typeof(Xml2json), new DesignerAttribute(typeof(Xml2jsonDesigner)));
            builder.AddCustomAttributes(typeof(Xml2json), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
